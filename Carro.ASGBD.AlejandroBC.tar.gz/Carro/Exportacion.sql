set echo on

spo Salida.txt

set linesize 200
set pagesize 3000

drop table Cliente cascade constraints;
drop table Pago cascade constraints;
drop table Dirección cascade constraints;
drop table Pedido cascade constraints;
drop table Linea.Pedido cascade constraints;
drop table Producto cascade constraints;

drop user Carro cascade;

create user CARRO identified by carro;
alter user CARRO default tablespace users;
grant unlimited tablespace to CARRO;
grant create session to CARRO;
grant create table to CARRO;
alter session set NLS_DATE_FORMAT = 'DD-MM-YYYY';
grant create view to CARRO;
conn CARRO/carro;


CREATE TABLE Cliente 
    ( 
     "Cli-Nombre" VARCHAR2 (100 CHAR)  NOT NULL 
    ) 
;



ALTER TABLE Cliente 
    ADD CONSTRAINT "Cliente PK" PRIMARY KEY ( "Cli-Nombre" ) ;



CREATE TABLE Direccion 
    ( 
     Calle VARCHAR2 (150 CHAR)  NOT NULL , 
     Ciudad VARCHAR2 (50 CHAR)  NOT NULL , 
     "Co-Postal" INTEGER  NOT NULL , 
     Pais VARCHAR2 (20 CHAR)  NOT NULL , 
     "Cli-Nombre" VARCHAR2 (100 CHAR) 
    ) 
;



ALTER TABLE Direccion 
    ADD CONSTRAINT "Dirección PK" PRIMARY KEY ( Calle ) ;



CREATE TABLE Linea 
    ( 
     "Nu-Unidades" INTEGER  NOT NULL , 
     "Precio-Total" INTEGER  NOT NULL , 
     "Id-Pedido" INTEGER  NOT NULL , 
     "Pro-Nombre" VARCHAR2 (100 CHAR)  NOT NULL 
    ) 
;




CREATE TABLE Pago 
    ( 
     "Metodo-Pago" VARCHAR2 (20 CHAR)  NOT NULL , 
     "Numero-Tarjeta" NVARCHAR2 (15)  NOT NULL , 
     Calle VARCHAR2 (150 CHAR)  NOT NULL , 
     "Id-Pedido" INTEGER  NOT NULL 
    ) 
;


CREATE UNIQUE INDEX Pago__IDX ON Pago 
    ( 
     "Id-Pedido" ASC 
    ) 
;

ALTER TABLE Pago 
    ADD CONSTRAINT "Pago PK" PRIMARY KEY ( "Numero-Tarjeta" ) ;



CREATE TABLE Pedido 
    ( 
     "Id-Pedido" INTEGER  NOT NULL , 
     Fecha DATE  NOT NULL , 
     "Cli-Nombre" VARCHAR2 (100 CHAR)  NOT NULL , 
     Calle VARCHAR2 (150 CHAR)  NOT NULL , 
     "Numero-Tarjeta" NVARCHAR2 (15)  NOT NULL 
    ) 
;


CREATE UNIQUE INDEX Pedido__IDX ON Pedido 
    ( 
     "Numero-Tarjeta" ASC 
    ) 
;

ALTER TABLE Pedido 
    ADD CONSTRAINT "Pedido PK" PRIMARY KEY ( "Id-Pedido" ) ;



CREATE TABLE Producto 
    ( 
     "Pro-Nombre" VARCHAR2 (100 CHAR)  NOT NULL , 
     "Pro-Precio" INTEGER  NOT NULL 
    ) 
;



ALTER TABLE Producto 
    ADD CONSTRAINT "Producto PK" PRIMARY KEY ( "Pro-Nombre" ) ;




ALTER TABLE Pedido 
    ADD CONSTRAINT Relation_23 FOREIGN KEY 
    ( 
     "Cli-Nombre"
    ) 
    REFERENCES Cliente 
    ( 
     "Cli-Nombre"
    ) 
    ON DELETE CASCADE 
;


ALTER TABLE Direccion 
    ADD CONSTRAINT Relation_24 FOREIGN KEY 
    ( 
     "Cli-Nombre"
    ) 
    REFERENCES Cliente 
    ( 
     "Cli-Nombre"
    ) 
;


ALTER TABLE Pago 
    ADD CONSTRAINT Relation_26 FOREIGN KEY 
    ( 
     Calle
    ) 
    REFERENCES Direccion 
    ( 
     Calle
    ) 
    ON DELETE CASCADE 
;


ALTER TABLE Pedido 
    ADD CONSTRAINT Relation_27 FOREIGN KEY 
    ( 
     Calle
    ) 
    REFERENCES Direccion 
    ( 
     Calle
    ) 
    ON DELETE CASCADE 
;


ALTER TABLE Linea 
    ADD CONSTRAINT Relation_28 FOREIGN KEY 
    ( 
     "Id-Pedido"
    ) 
    REFERENCES Pedido 
    ( 
     "Id-Pedido"
    ) 
    ON DELETE CASCADE 
;


ALTER TABLE Linea 
    ADD CONSTRAINT Relation_29 FOREIGN KEY 
    ( 
     "Pro-Nombre"
    ) 
    REFERENCES Producto 
    ( 
     "Pro-Nombre"
    ) 
    ON DELETE CASCADE 
;





ALTER TABLE Pedido 
    ADD CONSTRAINT Relation_40 FOREIGN KEY 
    ( 
     "Numero-Tarjeta"
    ) 
    REFERENCES Pago 
    ( 
     "Numero-Tarjeta"
    ) 
    ON DELETE CASCADE 
;

insert into Cliente values('Armando Bulla Jaleo');
insert into Cliente values('Isabel Pantoja Martinez');

insert into Direccion values ('Av.Piruleta', 'Caceres', 11013, 'Argentina', 'Armando Bulla Jaleo');
insert into Direccion values ('Av.de la Carcel', 'Alcala', 11000, 'España', 'Isabel Pantoja Martinez');

insert into Producto values ('Tambores mal afinados', 10);
insert into Producto values ('Bolsas de basura', 15);

insert into Pago values ('MasterCard', 11111111111, 'Av.Piruleta', 1);
insert into Pago values ('VisaBlack', 22222222222, 'Av.de la Carcel', 2);

insert into Pedido values (1, SYSDATE, 'Armando Bulla Jaleo', 'Av.Piruleta', 11111111111);
insert into Pedido values (2, SYSDATE, 'Isabel Pantoja Martinez', 'Av.de la Carcel', 22222222222);

insert into Linea values (5, 100, 1, 'Tambores mal afinados');
insert into Linea values (1, 10, 2, 'Bolsas de basura');

CREATE OR REPLACE VIEW Factura AS
SELECT Cliente."Cli-Nombre" AS Nombre,
  Direccion.Calle           AS Calle,
  Direccion.Ciudad          AS Ciudad,
  Direccion."Co-Postal"     AS "Codigo-Postal",
  Direccion.Pais            AS Pais,
  Pago."Metodo-Pago"        AS "Metodo-Pago",
  Pago."Numero-Tarjeta"     AS Tarjeta,
  Linea."Nu-Unidades"       AS Unidades,
  Linea."Precio-Total"      AS "Precio-Total",
  Producto."Pro-Nombre"     AS "Pro-Nombre",
  Producto."Pro-Precio"     AS "Pro-Precio",
  Pedido."Id-Pedido"        AS "Id-Pedido",
  Pedido.Fecha              AS Fecha
FROM Cliente
INNER JOIN Direccion
ON Cliente."Cli-Nombre" = Direccion."Cli-Nombre"
INNER JOIN Pago
ON Direccion.Calle = Pago.Calle
INNER JOIN Pedido
ON Pedido."Id-Pedido"     = Pago."Id-Pedido"
AND Cliente."Cli-Nombre"  = Pedido."Cli-Nombre"
AND Direccion.Calle       = Pedido.Calle
AND Pago."Numero-Tarjeta" = Pedido."Numero-Tarjeta"
INNER JOIN Linea
ON Pedido."Id-Pedido" = Linea."Id-Pedido"
INNER JOIN Producto
ON Producto."Pro-Nombre" = Linea."Pro-Nombre" ;

exit


spo off
